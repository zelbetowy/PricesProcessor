import time

while True:
    print("Witaj, świecie!")
    time.sleep(2)