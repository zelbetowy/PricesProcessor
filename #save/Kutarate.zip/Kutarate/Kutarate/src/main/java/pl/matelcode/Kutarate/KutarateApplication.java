package pl.matelcode.Kutarate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KutarateApplication {

	public static void main(String[] args) {
		SpringApplication.run(KutarateApplication.class, args);
		System.out.println("Ty huju");
	}

}
